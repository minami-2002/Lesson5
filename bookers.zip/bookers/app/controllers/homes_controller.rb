class HomesController < ApplicationController
end
